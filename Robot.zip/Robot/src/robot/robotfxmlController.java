/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package robot;

import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 *
 * @author asmar
 */
public class robotfxmlController implements Initializable {
    
    Process p;
    View v;
    boolean setup=false;
    BufferedReader stdInput;
    BufferedReader stdError;
    @FXML
    private Button host;
    @FXML
    private Button quit;

    @FXML
    private Button Stream;
    
    @FXML
    ImageView show;
    
    @FXML
    Label text;
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        if (event.getSource()==host){
            v.start();
        }
        else if(event.getSource()==quit){
            p.destroyForcibly();
            System.out.println("process closed");
        }
        else if(event.getSource()==Stream){
            if(setup){
            setup=false;
            show.setImage(null);
            }
            else{
                setup=true;
            }
        }
    }
  
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        v = new View();
    }    

class View extends Thread
{
    public File file;
    public Image image;
    public View(){}
    @Override
    public void run()
    {
        
        try {
            p = Runtime.getRuntime().exec("python host.py");
            stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));
            stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));
        } catch (IOException ex) {
            Logger.getLogger(robotfxmlController.class.getName()).log(Level.SEVERE, null, ex);
        }
            System.out.println("process started");
            while(p.isAlive()){
                try{
                    if(setup){
                    file = new File("image.jpg");
                    image = new Image(file.toURI().toString());
                    show.setImage(image);}
                    
                }catch(Exception e){
                    System.out.print(e);
                }
            }
    }

        
   }
    
}
