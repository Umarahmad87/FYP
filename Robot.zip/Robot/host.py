import io
import socket
import struct
import cv2
import numpy as np
import threading


server_socket = socket.socket()
server_socket.bind(('192.168.200.103', 3051))
server_socket.listen(0)


connection = server_socket.accept()[0].makefile('rb')
try:
    while True:
        image_len = struct.unpack('<L', connection.read(struct.calcsize('<L')))[0]
        if not image_len:
            break
        image_stream = io.BytesIO()
        image_stream.write(connection.read(image_len))
        image_stream.seek(0)

        data = np.fromstring(image_stream.getvalue(), dtype=np.uint8)
        imagedisp = cv2.imdecode(data, 1)
        imagedisp = cv2.circle(imagedisp,(int(320/2),int(240/2)),2,(255,0,0),2)   
        cv2.imshow('frame',imagedisp)
        cv2.imwrite("image.jpg",imagedisp)
        key = cv2.waitKey(20)
finally:
    connection.close()
    server_socket.close()