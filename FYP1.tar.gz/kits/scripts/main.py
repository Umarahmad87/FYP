from RobotManager import *

import sys
import threading


Client = 0








def main():
    Client=RobotManager()
    Client.program_start()

if __name__=="__main__":
    main()
