from robot import *
import threading
from Queue import Queue
import os
import random

R = 0
DL = 0
DR = 0
D = 0
tstop = Queue(maxsize=1)
class obstacleAvoidence:

    def make_move(self):
                
        try:
            global R
            global DL
            global DR
            global D
            
            R = RoboMovement()
            DL = DistanceCalculation(pin=[40,38])
            DR = DistanceCalculation(pin=[36,32])
            D = DistanceCalculation(pin=[18,16])
            R.setup()
            count = 5
            dist = 0
            global tstop
            choice = [R.left,R.right,R.left,R.right,R.left,R.right,R.left,R.right]
            while True:
                try:
                    dist = DL.sonic_distance()
                    print "Distance Left= ",dist
                    dist2 = DR.sonic_distance()
                    print "Distance Right= ",dist2
                    dist3 = D.sonic_distance()
                    print "Distance forward= ",dist3
                    self.checkObstacle(dist,dist3,dist2)
                    stop = tstop.get(False)
                    if(stop==False):
                        break
                    """if dist>=35:
                        R.forward(step=0.5,speed=50)
                        if count<=0:
                            R.right(step=0.15,speed=46)
                            count=6
                        
                    else:
                        ch_index = random.randint(0, 8)
                        print "selected function = ",ch_index
                        choice[ch_index](step=0.9,speed=45)"""
                        
                    count-=1
                    time.sleep(0.05)
                except Exception as e:
                    print e
                    continue
                
                #time.sleep(0.01)
                
        except:
            print "in main except"
            R.reset()
            D.reset()
        finally:
            print "finally closed"
            R.reset()
            D.reset()
    
        
        
    def checkObstacle(self,dl, df, dr):
        global R
        choice = [R.left,R.right,R.left,R.right,R.left,R.right,R.left,R.right]
        if dl < 35:
            print "move right"
            R.right(step = 0.3, speed=45)
        if dr < 35:
            print "move left"
            R.left(step=0.3, speed=45)
        if df < 35:
            ch_index = random.randint(0, len(choice)-1)
            print "move random = ",ch_index
            choice[ch_index](step=0.9,speed=45)
            
        else:
            R.forward(step=0.5, speed=45)
            
        
            
